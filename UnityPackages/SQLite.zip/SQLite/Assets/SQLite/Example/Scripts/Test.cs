﻿using UnityEngine;
using Mono.Data.Sqlite;
using UnityFramework.Database.SQLite;

public class Test : MonoBehaviour 
{
    SQLiteManager sql;
 
    void Start () 
    {
        //从指定路径下，读取名为sqlite4unity.db的数据库，没有则创建
        string path ="Assets/sqlite4unity.db";
        sql = new SQLiteManager("URI=file:" + path);
        string tableName = "test";

        if (!sql.IsTableExist(tableName))
        {
            //创建名为table1的数据表
            sql.CreateTable(tableName,new string[]{"ID","Name","Age","Email"},new string[]{"INTEGER","TEXT","INTEGER","TEXT"});
        }

        //插入两条数据
        sql.InsertValues(tableName,new string[]{"'1'","'张三'","'22'","'Zhang3@163.com'"});
        sql.InsertValues(tableName,new string[]{"'2'","'李四'","'25'","'Li4@163.com'"});
 
        //更新数据，将Name="张三"的记录中的Name改为"Zhang3"
        sql.UpdateValues(tableName, new string[]{"Name"}, new string[]{"'Zhang3'"}, "Name", "=", "'张三'");
 
        //插入3条数据
        sql.InsertValues(tableName,new string[]{"3","'王五'","25","'Wang5@163.com'"});
        sql.InsertValues(tableName,new string[]{"4","'王五'","26","'Wang5@163.com'"});
        sql.InsertValues(tableName,new string[]{"5","'王五'","27","'Wang5@163.com'"});
        
        //读取整张表
        SqliteDataReader reader = sql.ReadFullTable (tableName);
        while(reader.Read()) 
        {
            //读取数据
            Debug.Log("读取整表" + reader.GetInt32(reader.GetOrdinal("ID"))
                             + "  " + reader.GetString(reader.GetOrdinal("Name"))
                             + "  " + reader.GetInt32(reader.GetOrdinal("Age"))
                             + "  " + reader.GetString(reader.GetOrdinal("Email"))
            );
        }
 
        //删除Name="王五"且Age=26的记录,DeleteValuesOR方法类似
        sql.DeleteValuesAND(tableName, new string[]{"Name","Age"}, new string[]{"=","="}, new string[]{"'王五'","'26'"});
 

 
        //读取数据表中Age>=25的所有记录的ID和Name
        reader = sql.ReadTable (tableName, new string[]{"ID","Name"}, new string[]{"Age"}, new string[]{">="}, new string[]{"'25'"});
        while(reader.Read()) 
        {
            //读取数据
            Debug.Log("根据条件读表" + reader.GetInt32(reader.GetOrdinal("ID"))
            + "  " + reader.GetString(reader.GetOrdinal("Name"))
            );
        }
 
        //自定义SQL,删除数据表中所有Name="王五"的记录
        sql.ExecuteQuery($"DELETE FROM {tableName} WHERE NAME='王五'");
 
        //关闭数据库连接
        sql.Close();
        
        Debug.Log($"对文件：{path}的操作执行完毕");
    }
}