﻿using UnityEngine;
using Mono.Data.Sqlite;
using System;
using System.Collections.Generic;

namespace UnityFramework.Database.SQLite
{
    /// <summary>
    /// SQLite管理器
    /// 根据语句进行执行，方法扩展简单
    /// </summary>
    public class SQLiteManager
    {
        SqliteConnection dbConnection;
        SqliteCommand dbCommand;
        SqliteDataReader dataReader;
        
        public SQLiteManager(string connectionString)
        {
            try
            {
                dbConnection = new SqliteConnection(connectionString);
                dbConnection.Open();
            }
            catch (Exception e)
            {
                Debug.Log(e.Message);
            }
        }

        /// <summary>
        /// 执行SQL命令
        /// </summary>
        /// <returns>The query.</returns>
        /// <param name="queryString">SQL命令字符串</param>
        public SqliteDataReader ExecuteQuery(string queryString)
        {
            dbCommand = dbConnection.CreateCommand();
            dbCommand.CommandText = queryString;
            dataReader = dbCommand.ExecuteReader();
            return dataReader;
        }
        
        /// <summary>
        /// 关闭数据库
        /// </summary>
        public void Close()
        {
            if (dbCommand != null)
            {
                dbCommand.Cancel();
            }
            dbCommand = null;
            
            if (dataReader != null)
            {
                dataReader.Close();
            }
            dataReader = null;
            
            if (dbConnection != null)
            {
                dbConnection.Close();
            }
            dbConnection = null;
        }
        
        /// <summary>
        /// 创建数据表
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="colNames">列名</param>
        /// <param name="colTypes">列类型</param>
        /// <returns></returns>
        public SqliteDataReader CreateTable(string tableName, string[] colNames, string[] colTypes)
        {
            string queryString = "CREATE TABLE " + tableName + "( " + colNames[0] + " " + colTypes[0];
            for (int i = 1; i < colNames.Length; i++)
            {
                queryString += ", " + colNames[i] + " " + colTypes[i];
            }

            queryString += "  ) ";
            return ExecuteQuery(queryString);
        }

        /// <summary>
        /// 插入值
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="values">数据值</param>
        /// <returns></returns>
        /// <exception cref="SqliteException"></exception>
        public SqliteDataReader InsertValues(string tableName, string[] values)
        {
            int fieldCount = ReadFullTable(tableName).FieldCount;
            if (values.Length != fieldCount)
            {
                throw new SqliteException("values.Length!=fieldCount");
            }

            string queryString = "INSERT INTO " + tableName + " VALUES (" + values[0];
            for (int i = 1; i < values.Length; i++)
            {
                queryString += ", " + values[i];
            }

            queryString += " )";
            return ExecuteQuery(queryString);
        }
        
        /// <summary>
        /// 更新值
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="colNames">列名</param>
        /// <param name="colValues">列值</param>
        /// <param name="key">查询键</param>
        /// <param name="operation">操作符</param>
        /// <param name="value">更新值</param>
        /// <returns></returns>
        /// <exception cref="SqliteException"></exception>
        public SqliteDataReader UpdateValues(string tableName, string[] colNames, string[] colValues, string key, string operation, string value)
        {
            if (colNames.Length != colValues.Length)
            {
                throw new SqliteException("colNames.Length!=colValues.Length");
            }

            string queryString = "UPDATE " + tableName + " SET " + colNames[0] + "=" + colValues[0];
            for (int i = 1; i < colValues.Length; i++)
            {
                queryString += ", " + colNames[i] + "=" + colValues[i];
            }

            queryString += " WHERE " + key + operation + value;
            return ExecuteQuery(queryString);
        }
        
        /// <summary>
        /// 删除值
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="colNames">列名</param>
        /// <param name="operations">操作符</param>
        /// <param name="colValues">列值</param>
        /// <returns></returns>
        /// <exception cref="SqliteException"></exception>
        public SqliteDataReader DeleteValuesOR(string tableName, string[] colNames, string[] operations, string[] colValues)
        {
            //当字段名称和字段数值不对应时引发异常
            if (colNames.Length != colValues.Length || operations.Length != colNames.Length || operations.Length != colValues.Length)
            {
                throw new SqliteException(
                    "colNames.Length!=colValues.Length || operations.Length!=colNames.Length || operations.Length!=colValues.Length");
            }

            string queryString = "DELETE FROM " + tableName + " WHERE " + colNames[0] + operations[0] + colValues[0];
            for (int i = 1; i < colValues.Length; i++)
            {
                queryString += "OR " + colNames[i] + operations[0] + colValues[i];
            }

            return ExecuteQuery(queryString);
        }
        
        /// <summary>
        /// 删除值
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="colNames">列名</param>
        /// <param name="operations">操作符</param>
        /// <param name="colValues">列值</param>
        /// <returns></returns>
        /// <exception cref="SqliteException"></exception>
        public SqliteDataReader DeleteValuesAND(string tableName, string[] colNames, string[] operations, string[] colValues)
        {
            //当字段名称和字段数值不对应时引发异常
            if (colNames.Length != colValues.Length || operations.Length != colNames.Length || operations.Length != colValues.Length)
            {
                throw new SqliteException(
                    "colNames.Length!=colValues.Length || operations.Length!=colNames.Length || operations.Length!=colValues.Length");
            }

            string queryString = "DELETE FROM " + tableName + " WHERE " + colNames[0] + operations[0] + colValues[0];
            for (int i = 1; i < colValues.Length; i++)
            {
                queryString += " AND " + colNames[i] + operations[i] + colValues[i];
            }

            return ExecuteQuery(queryString);
        }
        
        /// <summary>
        /// 读表
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="readColNames">读取的列类型</param>
        /// <param name="judgeColNames">判断的列类型</param>
        /// <param name="operations">操作符</param>
        /// <param name="colValues">列值</param>
        /// <returns></returns>
        public SqliteDataReader ReadTable(string tableName, string[] readColNames, string[] judgeColNames, string[] operations, string[] colValues)
        {
            string queryString = "SELECT " + readColNames[0];
            for (int i = 1; i < readColNames.Length; i++)
            {
                queryString += ", " + readColNames[i];
            }

            queryString += " FROM " + tableName + " WHERE " + judgeColNames[0] + " " + operations[0] + " " + colValues[0];
            for (int i = 0; i < judgeColNames.Length; i++)
            {
                queryString += " AND " + judgeColNames[i] + " " + operations[i] + " " + colValues[0] + " ";
            }

            return ExecuteQuery(queryString);
        }
        
        /// <summary>
        /// 读取整表
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <returns></returns>
        public SqliteDataReader ReadFullTable(string tableName)
        {
            string queryString = "SELECT * FROM " + tableName;
            return ExecuteQuery(queryString);
        }
        
        /// <summary>
        /// 获取所有的表名
        /// </summary>
        /// <returns></returns>
        public List<string> GetAllTableNames()
        {
            string queryString = "select name from sqlite_master where type='table'";
            var a = ExecuteQuery(queryString);
            List<string> ownTableNames = null;
            while (a.Read())
            {
                if (ownTableNames == null)
                {
                    ownTableNames = new List<string>();
                }

                ownTableNames.Add(a.GetString(0));
            }

            return ownTableNames;
        }
        
        /// <summary>
        /// 判断表是否存在于数据库中
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <returns></returns>
        public bool IsTableExist(string tableName)
        {
            string queryString = "select name from sqlite_master where type='table'";
            var a = ExecuteQuery(queryString);
            while (a.Read())
            {
                if (a.GetString(0) == tableName)
                    return true;
            }

            return false;
        }
    }
}